<?php include('includes/header.php');?>
<?php

  $pageno = $no_of_records_per_page = $offset = $total_rows =$total_pages=0;
  

  //pagenation code
  if (isset($_GET['pageno'])) {
    $pageno = (int)$_GET['pageno'];
  } 
  else {
    $pageno = 1;
  }

  $no_of_records_per_page = 2;
  $offset = ($pageno-1) * $no_of_records_per_page;


  $total_pages_sql = "SELECT COUNT(*) FROM students";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_rows = mysqli_fetch_array($result)[0];
  $total_pages = ceil($total_rows / $no_of_records_per_page);

  //select data
  $sqlStudents = "SELECT student_id, student_name,student_father,student_mother,student_dob,student_email,student_address,  student_phone,student_gender,student_class FROM students LIMIT $offset, $no_of_records_per_page";

  $result = mysqli_query($conn, $sqlStudents);
  $count=1;

?>

<? php echo $student_id; ?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown active show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="student-add.php">Admit Student</a>
      <a class="dropdown-item active" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item" href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->
<!-- Edit Modal-->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Student</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="student-edit.php?page=<?php echo $_GET['pageno']?>" method="post">
        
        <div class="modal-body">
          <!-- <input type="hidden" name="update_id" id="update_id">-->
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Stduent Id</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_id" id="s_id" placeholder="Stduent Id" readonly>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Stduent Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_name" id="s_name" placeholder="Stduent Name" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Father Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_father" id="s_father" placeholder="Father Name" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Mother Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_mother" id="s_mother" placeholder="Mother Name" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Date of Birth</label>
            <div class="col-sm-10">
              <input type="date" class="form-control" name="student_dob" id="s_dob" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" name="student_email" id="s_email" placeholder="@Email" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Address</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_address" id="s_address" placeholder="Address" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Phone</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="student_phone" id="s_phone" placeholder="Phone" required>
            </div>
          </div>
          <fieldset class="form-group">
            <div class="row">
              <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
              <div class="col-sm-10">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="student_gender" value="Male">
                  <label class="form-check-label">
                    Male
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="student_gender" value="Female">
                  <label class="form-check-label">
                    Female
                  </label>
                </div>
              </div>
            </div>
          </fieldset>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Class</label>
            <div class="col-sm-10">
              <select class="custom-select" id="s_class" name='student_class' required>
                <option selected>Select Class</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
                <option value="4">Four</option>
                <option value="5">Five</option>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-primary" name="updatedata" type="submit" >Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End Edit Modal-->
<!-- Delete Modal-->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Student</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="student-delete.php?page=<?php echo $_GET['pageno']?>" method="post">
        
        <div class="modal-body">
          <input type="hidden" name="student_id" id="ds_id">
          <h4>Do You Want To Delete This Data?</h4>
          
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-danger" name="deletedata" type="submit" >Delete</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End Delete Modal-->
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Student</a>
      </li>
      <li class="breadcrumb-item active">Student Information</li>
    </ol>
    <!-- Page Content -->
    <div class="form-group row">
      <div class="col-sm-11">
        <h1><i class="fas fa-table"></i> Student Information</h1>
      </div>
      <!--<div class="col-sm-1">
        <select class="custom-select my-1 mr-sm-2" name="page_item_no">
          <option value="2">2</option>
          <option value="5">5</option>
          <option value="10" selected>10</option>
          <option value="15">15</option>
        </select>
      </div>-->
    </div>

    <hr>
    <table class="table table-hover table-bordered">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Student Id</th>
          <th scope="col">Student Name</th>
          <th scope="col">Father Name</th>
          <th scope="col">Mother Name</th>
          <th scope="col">Date Of Birth</th>
          <th scope="col">Email</th>
          <th scope="col">Address</th>
          <th scope="col">Phone</th>
          <th scope="col">Gender</th>
          <th scope="col">Class</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <!--<tr>
          <td scope="row">1</td>
          <td>33-0001</td>
          <td>Otto von Bismarck</td>
          <td>von Bismarck</td>
          <td>Lady von Bismarck</td>
          <td>1998-10-30</td>
          <td>von@mail.com</td>
          <td>Berlin</td>
          <td>032847323</td>
          <td>Male</td>
          <td>1</td>
          <td class="sorting_1">&nbsp;&nbsp;
            <button type="button" class="btn btn-success btm-sm editbtn" data-toggle="modal" data-target="#editmodal"
            data-no="1"
            data-id="33-0001"
            data-name="Otto von Bismarck"
            data-fname="von Bismarck"
            data-mname="Lady von Bismarck"
            data-dob="1998-10-30"
            data-email="von@mail.com"
            data-add="Berlin"
            data-phone="032847323"
            data-gender="Male"
            data-class="1"
            ><i class="fa fa-edit"></i></button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button type="button" class="btn btn-danger btm-sm"><i class="fa fa-trash"></i></button>
          </td>
        </tr>-->
        <tr>
          <td scope="row"><?php echo $count; ?></td>
          <td><?php echo $row['student_id']; ?></td>
          <td><?php echo $row['student_name']; ?></td>
          <td><?php echo $row['student_father']; ?></td>
          <td><?php echo $row['student_mother']; ?></td>
          <td><?php echo $row['student_dob']; ?></td>
          <td><?php echo $row['student_email']; ?></td>
          <td><?php echo $row['student_address']; ?></td>
          <td><?php echo $row['student_phone']; ?></td>
          <td><?php echo $row['student_gender']; ?></td>
          <td><?php echo $row['student_class']; ?></td>
          <td class="sorting_1">&nbsp;&nbsp;
            <button type="button" class="btn btn-success btm-sm editbtn" data-toggle="modal" data-target="#editmodal"
            data-id="<?php echo $row['student_id']; ?>"
            data-name="<?php echo $row['student_name']; ?>"
            data-fname="<?php echo $row['student_father']; ?>"
            data-mname="<?php echo $row['student_mother']; ?>"
            data-dob="<?php echo $row['student_dob']; ?>"
            data-email="<?php echo $row['student_email']; ?>"
            data-add="<?php echo $row['student_address']; ?>"
            data-phone="<?php echo $row['student_phone']; ?>"
            data-gender="<?php echo $row['student_gender']; ?>"
            data-class="<?php echo $row['student_class']; ?>"
            ><i class="fa fa-edit"></i></button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button type="button" class="btn btn-danger btm-sm deletebtn" data-toggle="modal" data-target="#deletemodal" data-id = "<?php echo $row['student_id']; ?>"><i class="fa fa-trash"></i></button>
          </td>
        </tr>
        <?php $count++; } ?>
      </tbody>
    </table>

    <ul class="pagination justify-content-end">
      

      <li class="paginate_button page-item previous <?php if($pageno <= 1){ echo "disabled"; } ?>"
      id="dataTable_previous"><a href="student-view.php?pageno=<?php 
      if($pageno <= 1){ echo '1'; } else { echo (strval($pageno - 1)); } ?>" 
      aria-controls="dataTable" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li>
      
      <?php
      for($i=1; $i<=$total_pages; $i++){ ?>
      <li class="paginate_button page-item" id="<?php echo $i; ?>"><a href="student-view.php?pageno=<?php echo $i; ?>" aria-controls="dataTable" data-dt-idx="1" tabindex="0" class="page-link"><?php echo $i;} ?></a></li>
      

      <li class="paginate_button page-item next <?php if($pageno >= $total_pages){ echo 'disabled'; } ?>" 
      id="dataTable_next"><a href="student-view.php?pageno=<?php 
      if($pageno >= $total_pages){ echo $total_pages; } else { echo (strval($pageno + 1)); } ?>" 
      aria-controls="dataTable" data-dt-idx="7" tabindex="0" class="page-link">Next</a></li>



    </ul>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>
  
  <!-- Scripts for Modal And Fetching data from table-->
<script type="text/javascript">
$(document).on( "click", '.editbtn',function(e) {

    //var update_id = $(this).data('no');
    var s_id = $(this).data('id');
    var s_name = $(this).data('name');
    var s_father = $(this).data('fname');
    var s_mother = $(this).data('mname');
    var s_dob = $(this).data('dob');
    var s_email = $(this).data('email');
    var s_address = $(this).data('add');
    var s_phone = $(this).data('phone');
    var s_gender = $(this).data('gender');
    var s_class = $(this).data('class');
    
    

    //$('#update_id').val(update_id);
    $('#s_id').val(s_id);
    $('#s_name').val(s_name);
    $('#s_father').val(s_father);
    $('#s_mother').val(s_mother);
    $('#s_dob').val(s_dob);
    $('#s_email').val(s_email);
    $('#s_address').val(s_address);
    $('#s_phone').val(s_phone);
    $('input[type=radio][value=' + s_gender + ']').attr('checked', true);
    $('#s_class').val(s_class);

});
</script>

<script type="text/javascript">
$(document).on( "click", '.deletebtn',function(e) {

    var s_id = $(this).data('id');
    
    
    $('#ds_id').val(s_id);

});

/*$(document).ready( function () {
    $('.table').DataTable();
} );*/

$('<?php echo "#".$pageno; ?>').addClass('active');
</script>

<?php include('includes/footer.php');?>