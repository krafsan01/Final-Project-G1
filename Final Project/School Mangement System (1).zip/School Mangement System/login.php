<?php
include "includes/db_connect.inc.php";

session_start();
$uPass = $uName = $message = "";

/* mysqli_real_escape_string() helps prevent sql injection */
if($_SERVER["REQUEST_METHOD"] == "POST"){

    if(!empty($_POST['user_name'])){
        $uName = mysqli_real_escape_string($conn, $_POST['user_name']);
    }
    if(!empty($_POST['user_pass'])){
        $uPass = mysqli_real_escape_string($conn, $_POST['user_pass']);
    }

    $sqlUserCheck = "SELECT user_name, password FROM users WHERE user_name = '$uName'";
    $result = mysqli_query($conn, $sqlUserCheck);
    $rowCount = mysqli_num_rows($result);

    if($rowCount < 1){
        $message = "User does not exist!";
    }
    else{
        while($row = mysqli_fetch_assoc($result)){
            $uPassInDB = $row['password'];

            if($uPass == $uPassInDB || password_verify($uPass, $uPassInDB)){
                $_SESSION['username'] = $uName;
                $_SESSION['password'] = $uPass;
                $user_power = (int)(explode("-",$uName,-1)[0]);
                echo $user_power;
                if($user_power == 11)
                    header("Location: admin/dashboard.php");
                elseif ($user_power == 33)
                    header("Location: teacher/dashboard.php");
                elseif ($user_power == 22)
                    header("Location: student/dashboard.php");
            }
            else{
                $message = "Wrong Password!";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
<title></title>
<style type="text/css">
    table{
        margin-top: 150;
        border: 1px solid;
        background-color: #eee;
    }
    td{
        border: 0px;
        padding: 10px;
    }
    th{
        border-bottom: 1px solid;
        background-color: #ddd;
    }
</style>
</head>
    <body>
        <form method="post">
            <table align="center" height="300px">
                <tr height="200px">
                    <th colspan="2">XYZ SCHOOL<br><a href="/School Mangement System/Home Webpage/webpage.html"><img src="img/xyz.jpg" height="150px" width="250px" align="center" ></a><br>Login Organizational ID</th>
                </tr>
                <tr>
                    <td>User ID:</td>
                    <td><input type="text" name="user_name" id="uid" required></td>
                </tr>

                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="user_pass" id="pass" required=""></td>
                </tr>
                <tr>
                    <td><input type="checkbox" onclick="myFunction()">Show Password</td>
                </tr>
                <tr>
                    <td align="right" colspan="2"><span style="color:red"><?php echo $message; ?></span><input type="submit" name="submit" value="Login"></td>
                </tr>

            </table>

        </form>
    </body>
</html>

<script type="text/javascript">
function myFunction() {
  var pass = document.getElementById("pass");
  if (pass.type === "password") {
    pass.type = "text";
  } else {
    pass.type = "password";
  }
}
</script>
