<?php include('includes/header.php');?>
<?php

  //select data
  $sqlTeachers = "SELECT teacher_name,teacher_merit, teacher_email,teacher_gender,teacher_dob,teacher_dept FROM teachers";

  $result = mysqli_query($conn, $sqlTeachers);
  $count=1;

?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>My Profile</span>
        </a>
      </li>
     <li class="nav-item active">
        <a class="nav-link" href="teacher-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Teachers</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subjects</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="exam-view.php">
          <i class="fas fa-marker"></i>
          <span>Your Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Teacher</a>
      </li>
      <li class="breadcrumb-item active">Teacher Information</li>
    </ol>
    <!-- Page Content -->
    <div class="form-group row">
      <div class="col-sm-11">
        <h1><i class="fas fa-table"></i> Teacher Information</h1>
      </div>
    </div>
    <hr>
    <table class="table table-hover table-bordered">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Teacher Name</th>
          <th scope="col">Date of Birth</th>
          <th scope="col">Email</th>
          <th scope="col">Gender</th>
          <th scope="col">Department</th>
          <th scope="col">Merit</th>     
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td scope="row"><?php echo $count; ?></td>
          <td><?php echo $row['teacher_name']; ?></td>
          <td><?php echo $row['teacher_dob']; ?></td>
          <td><?php echo $row['teacher_email']; ?></td>
          <td><?php echo $row['teacher_gender']; ?></td>
          <td><?php echo $row['teacher_dept']; ?></td>
          <td><?php echo $row['teacher_merit']; ?></td>
        </tr>
        <?php $count++; } ?>
      </tbody>
    </table>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>
  
  <!-- Scripts for Modal And Fetching data from table-->

<script type="text/javascript">
$(document).ready( function () {
    $('.table').DataTable();
} );
</script>

<?php include('includes/footer.php');?>