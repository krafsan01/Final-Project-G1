
<?php include('includes/header.php');?>
<?php

$exam_id=$exam_name=$exam_date="";


$result=$messege=$success_messege=$sql_exam=$sql_login=$password=$password_hash="";

$exam_idInDB=$exam_id_err="";

if($_SERVER['REQUEST_METHOD'] == "POST"){
  
    if((!empty($_POST['exam_id']))&&(!empty($_POST['exam_name']))&& (!empty($_POST['exam_date'])))
    {
      $exam_id = mysqli_real_escape_string($conn, $_POST['exam_id']);
      $exam_name = mysqli_real_escape_string($conn, $_POST['exam_name']);
      $exam_date = mysqli_real_escape_string($conn, $_POST['exam_date']);
      
    }
  


    $sqlUserCheck = "SELECT exam_id FROM exams WHERE exam_id = '$exam_id'";
    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $exam_idInDB = $row['exam_id'];
    }
    $check=(bool)$exam_idInDB == $exam_id;
    if($exam_idInDB == $exam_id){
      $exam_id_err = "Same exam_id already exists!";
    }
    else
    {
      $sql_exam = "INSERT INTO exams (exam_id, exam_name,exam_date) VALUES ('$exam_id', '$exam_name','$exam_date');";
      mysqli_query($conn, $sql_exam);
      $success_messege = "Data Inserted!" ;
    }

}



?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown ">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu " aria-labelledby="pagesDropdown">
      <a class="dropdown-item " href="student-add.php">Admit Student</a>
      <a class="dropdown-item" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item" href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item active" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Exam</a>
      </li>
      <li class="breadcrumb-item active">Add Exam</li>
    </ol>
    <!-- Page Content -->
    <h1>Add Exam</h1>
    <hr>
    <form role="form" method="post">
      <input type="hidden" name="new" value="1" />
      <div class="form-group row">
        <label for="inputText3" class="col-sm-2 col-form-label">Exam Id</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputText3" name="exam_id" placeholder="Exam Id" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Exam Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="exam_name" placeholder="Exam Name" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Exam Date</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" name="exam_date" placeholder="Exam Date" required>
        </div>
      </div>
       
      <div class="form-group row">
        <div class="col-sm-12">
          <button type="submit" class="btn btn-primary">Save</button>
          <span class="text-success"><?php echo $success_messege?></span>
          <span class="text-danger"><?php echo $exam_id_err ?></span>
        </div>
      </div>
    </form>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
 <?php include('includes/scripts.php');?>
  <!-- <script>
$( "form" ).submit(function( event ) {
  var id = "<?php //echo $student_id?>";
  var idInDB = "<?php //echo $student_idInDB?>";

  if ( <?php //echo $check ?> ) {
    $( ".text-success" ).text( "<?php //echo $success_messege?>" ).show();
    return;
  }

  $("#inputText3").val("");
  $( ".text-danger" ).text("Same student_id already exists!").show().fadeOut( 3000 );
  event.preventDefault();
});
</script>-->
  <?php include('includes/footer.php');?>