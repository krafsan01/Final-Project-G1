<?php include('includes/header.php');?>
<?php

$subject_name=$subject_class=$subject_teacher="";


$result=$messege=$success_messege=$sql_subject=$sql_login=$password=$password_hash="";

$subject_nameInDB=$subject_name_err="";

$selectTeacher=$teacher_no = "";

if($_SERVER['REQUEST_METHOD'] == "POST"){
  
    if((!empty($_POST['subject_name']))&&(!empty($_POST['subject_class']))&& (!empty($_POST['subject_teacher'])))
    {
      $subject_name = mysqli_real_escape_string($conn, $_POST['subject_name']);
      $subject_class = mysqli_real_escape_string($conn, ((int)$_POST['subject_class']));
      $subject_teacher = mysqli_real_escape_string($conn, $_POST['subject_teacher']);

    }

    /*$selectTeacher = "SELECT teacher_no FROM teachers WHERE teacher_name = '$subject_teacher'";
    $result = mysqli_query($conn, $selectTeacher);
    $teacher_no = mysqli_fetch_array($result)[0];
    $teacher_no = (int)$teacher_no;*/
    $teacher_no = (int)$subject_teacher;

    $sqlUserCheck = "SELECT s.subject_name FROM subjects s, subjects_teachers st WHERE s.subject_name = '$subject_name' AND st.subject_no = $teacher_no";
    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $subject_nameInDB = $row['subject_name'];
    }
    $check=(bool)$subject_nameInDB == $subject_name;
    if($subject_nameInDB == $subject_name){
      $subject_name_err = "Same subject_name already exists!";
    }
    else
    {
      $sql_subject = "INSERT INTO subjects (subject_name) VALUES ('$subject_name');";
      mysqli_query($conn, $sql_subject);

      $selectSubject = "SELECT subject_no FROM subjects WHERE subject_name = '$subject_name'";
      $result = mysqli_query($conn, $selectSubject);
      $subject_no = mysqli_fetch_array($result)[0];
      $subject_no = (int)$subject_no;

      
      $sql_ST = "INSERT INTO subjects_teachers (subject_no, teacher_no, class_no) VALUES ($subject_no,$teacher_no,$subject_class);";
      mysqli_query($conn, $sql_ST);
      $success_messege = "Data Inserted!";
    }

}



?>

<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="student-add.php">Admit Student</a>
      <a class="dropdown-item" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item" href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown active show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item active" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Student</a>
      </li>
      <li class="breadcrumb-item active">Admit Student</li>
    </ol>
    <!-- Page Content -->
    <h1>Add Subject</h1>
    <hr>
    <form role="form" method="post">
      <input type="hidden" name="new" value="1" />
      <div class="form-group row">
        <label for="inputText3" class="col-sm-2 col-form-label">Subject Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputText3" name="subject_name" placeholder="Subject Name" required>
        </div>
        </div>
        <div class="form-group row">
        <label class="col-sm-2 col-form-label">Class</label>
        <div class="col-sm-10">
          <select class="custom-select" name="subject_class" required>
            <option selected>Select Class</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
            <option value="4">Four</option>
            <option value="5">Five</option>
          </select>
        </div>
        </div>
        <div class="form-group row">
        <label class="col-sm-2 col-form-label">Teacher</label>
        <div class="col-sm-10">
          <select class="custom-select" name="subject_teacher" required>
            <option selected>Select Class</option>
            <?php 
            $selectTeacherfordd = "SELECT teacher_no, teacher_name FROM teachers";
            $t_result = mysqli_query($conn, $selectTeacherfordd);
            while ($row = mysqli_fetch_array($t_result)) {
            echo "<option value='" .$row['teacher_no'] . "'>" . $row['teacher_name'] . "</option>";
            }?>
          </select>
        </div>
        </div>

        <div class="form-group row">
        <div class="col-sm-12">
          <button type="submit" class="btn btn-primary">Save</button>
          <span class="text-success"><?php echo $success_messege?></span>
          <span class="text-danger"><?php echo $subject_name_err ?></span>
        </div>
        </div>
        </form>
        <!-- End Page Content -->
        </div>
  <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>