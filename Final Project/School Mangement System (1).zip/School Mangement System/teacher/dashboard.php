<?php include('includes/header.php');?>
<?php

  $sql = "SELECT * FROM teachers WHERE teacher_id = '$uname';";
  $result = mysqli_query($conn,$sql);
  $row = mysqli_fetch_array($result);

  $total_pages_sql = "SELECT COUNT(*) FROM students";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_students = mysqli_fetch_array($result)[0];

  $total_pages_sql = "SELECT COUNT(*) FROM teachers";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_teachers = mysqli_fetch_array($result)[0];

  $total_pages_sql = "SELECT COUNT(*) FROM admins";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_admins = mysqli_fetch_array($result)[0];

  $total_pages_sql = "SELECT COUNT(*) FROM books";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_books = mysqli_fetch_array($result)[0];
 ?>
<?php include('includes/navbar.php');?>

<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Page Content -->
        <h1>Teacher Dashboard</h1>
        <hr>
        <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-book-reader"></i>
                </div>
                <div class="mr-5"><?php echo $total_students; ?> Student!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="student-view.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-chalkboard-teacher"></i>
                </div>
                <div class="mr-5"><?php echo $total_teachers;?> Teachers</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="teacher-view.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-book-reader"></i>
                </div>
                <div class="mr-5"><?php echo $total_admins;?> Admins!</div>
              </div>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-danger o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-book-open"></i>
                </div>
                <div class="mr-5"><?php echo $total_books;?> Books!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="books-view.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>
        </div>
        <div class="card-body">
          <a>
            <h4 class="card-title"><?php echo $name;?></h4>
          </a>
          <a class="card-meta">Teacher</a><br>
          <a class="card-meta"><?php echo $row['teacher_id'] ;?></a><br>
          <a class="card-meta"><?php echo $row['teacher_email']; ?></a>
          <hr>
        </div>
        <!-- End Page Content -->

      </div>
      <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>
