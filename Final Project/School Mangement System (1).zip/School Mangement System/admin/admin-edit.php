<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}
include "../includes/db_connect.inc.php";

$admin_id=$admin_name=$admin_father=$admin_mother=$admin_email=$admin_phone=$admin_address=$admin_gender=$admin_dob=$admin_jd="";

  if(isset($_POST['updatedata'])){
    
    $admin_id = mysqli_real_escape_string($conn, $_POST['admin_id']);
    $admin_name = mysqli_real_escape_string($conn, $_POST['admin_name']);
    $admin_father = mysqli_real_escape_string($conn, $_POST['admin_father']);
    $admin_mother = mysqli_real_escape_string($conn, $_POST['admin_mother']);
    $admin_address = mysqli_real_escape_string($conn, $_POST['admin_address']);
    $admin_email = mysqli_real_escape_string($conn, $_POST['admin_email']);
    $admin_phone = mysqli_real_escape_string($conn, $_POST['admin_phone']);
    $admin_gender = mysqli_real_escape_string($conn, $_POST['admin_gender']);
    $admin_dob = mysqli_real_escape_string($conn, $_POST['admin_dob']);
    $admin_jd = mysqli_real_escape_string($conn, ((int)$_POST['admin_jd']));
    

    $sql_admin = "UPDATE admins SET admin_name ='$admin_name', admin_address ='$admin_address', admin_email ='$admin_email', admin_email ='$admin_email', admin_phone ='$admin_phone',admin_gender='$admin_gender',admin_dob='$admin_dob',admin_jd='$admin_jd' WHERE admin_id = '$id';";
    $query_run = mysqli_query($conn, $sql_admin);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:admin-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>