<?php include('includes/header.php');?>
<?php
  $pageno = $no_of_records_per_page = $offset = $total_rows =$total_pages=0;

  $student_id = $_SESSION["username"];
  $sqlStu = "SELECT student_class FROM students WHERE student_id='$student_id';";
  $result = mysqli_query($conn,$sqlStu);
  $student_class = ((int)mysqli_fetch_array($result)[0]);

  //select data
  $sqlSubjects = "SELECT subjects_teachers.*, subjects.subject_name, teachers.teacher_name, classes.class_name FROM subjects_teachers JOIN subjects ON subjects_teachers.subject_no = subjects.subject_no JOIN teachers ON subjects_teachers.teacher_no = teachers.teacher_no JOIN classes ON subjects_teachers.class_no = classes.class_no WHERE subjects_teachers.class_no = $student_class ORDER BY subjects_teachers.st_no asc";

  $result = mysqli_query($conn, $sqlSubjects);
  $count=1;

?>

<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>My Profile</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Teachers</span>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subjects</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="exam-view.php">
          <i class="fas fa-marker"></i>
          <span>Your Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Subject</a>
      </li>
      <li class="breadcrumb-item active">Subject Information</li>
    </ol>
    <!-- Page Content -->
    <div class="form-group row">
      <div class="col-sm-11">
        <h1><i class="fas fa-table"></i> Subject Information</h1>
      </div>
      <!--<div class="col-sm-1">
        <select class="custom-select my-1 mr-sm-2" name="page_item_no">
          <option value="2">2</option>
          <option value="5">5</option>
          <option value="10" selected>10</option>
          <option value="15">15</option>
        </select>
      </div>-->
    </div>

    <hr>
    <table class="table table-hover table-bordered">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Subject Name</th>
          <th scope="col">Class</th>
          <th scope="col">Teacher</th>
          
          
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td scope="row"><?php echo $count; ?></td>
          <td><?php echo $row['subject_name']; ?></td>
          <td><?php echo $row['class_no']; ?></td>
          <td><?php echo $row['teacher_name']; ?></td>
        </tr>
        <?php $count++; } ?>
      </tbody>
    </table>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>
  
  <!-- Scripts for Modal And Fetching data from table-->

<script type="text/javascript">
  $(document).ready( function () {
    $('.table').DataTable();
} );
</script>


<?php include('includes/footer.php');?>