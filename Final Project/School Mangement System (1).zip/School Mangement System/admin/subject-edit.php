<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}
include "../includes/db_connect.inc.php";

$subject_name=$subject_class=$subject_teacher="";

  if(isset($_POST['updatedata'])){

    $st_no = mysqli_real_escape_string($conn, ((int)$_POST['st_no']));
    $subject_no = mysqli_real_escape_string($conn, ((int)$_POST['subject_no']));
    $subject_name = mysqli_real_escape_string($conn, $_POST['subject_name']);
    $subject_class = mysqli_real_escape_string($conn, ((int)$_POST['subject_class']));
    $subject_teacher = mysqli_real_escape_string($conn, $_POST['subject_teacher']);

    $teacher_no = (int)$subject_teacher;
   
    

    $sql_sub = "UPDATE subjects SET subject_name ='$subject_name' WHERE subject_no = $subject_no;";
    $query_run = mysqli_query($conn, $sql_sub);
    $sql_ST = "UPDATE subjects_teachers SET subject_no = $subject_no ,class_no = $subject_class ,teacher_no = $teacher_no WHERE st_no = $st_no;";
    $query_run = mysqli_query($conn, $sql_ST);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:subject-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>