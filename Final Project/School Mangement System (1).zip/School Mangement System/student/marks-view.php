<?php include('includes/header.php');?>
<?php
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$exam_no = mysqli_real_escape_string($conn, ((int)$_POST['marks_exam']));
}


$selectSubject = "SELECT student_no FROM students WHERE student_id = '$uname';";
$result = mysqli_query($conn, $selectSubject);
$student_no = (int)mysqli_fetch_array($result)[0];
//echo $student_no;

$selectSubject = "SELECT exam_name FROM exams WHERE exam_no = $exam_no;";
$result = mysqli_query($conn, $selectSubject);
$exam_name = mysqli_fetch_array($result)[0];

$sqlMarks = "SELECT marks.*, subjects.subject_name FROM marks JOIN subjects ON marks.subject_no=subjects.subject_no WHERE marks.student_no = $student_no AND marks.exam_no = $exam_no ORDER BY mark_no ASC;";
$result = mysqli_query($conn, $sqlMarks);

$count = 1;
?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>My Profile</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Teachers</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subjects</span>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="exam-view.php">
          <i class="fas fa-marker"></i>
          <span>Your Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="select-marks.php">Show Marks</a>
      </li>
      <li class="breadcrumb-item active">Show Marks</li>
    </ol>
    <!-- Page Content -->
    <h1>Show Marks</h1>
    <hr>
	<center>
	<div class="col-sm-4">
		<div class="card bg-light mb-4" style="max-width: 18rem;">
			<div class="card-body">
				<h4 class="card-title">Marks of <?php echo $exam_name?> Exam</h4>
			</div>
		</div>
	</div>
	<div class="card">
		<div class="card-header"><h4>Your Marks</h4></div>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>#</th>
					<th>SUBJECT NAME</th>
					<th>MARKS OBTAINED</th>
					<th>COMMENTS</th>
				</tr>
			</thead>
			<tbody>
				<?php while($row = mysqli_fetch_array($result) ){

				$subject_name = $row['subject_name'];
				$mark_no = $row['mark_no'];
				$mark = $row['mark'];
				$comment = $row['comment'];
				if(empty($mark) AND empty($comment))
					{$mark = 0;$comment="No Comment";}
				?>
				<tr>
					<td><?php echo $count; ?></td>
					<td><?php echo $subject_name; ?></td>
					<td><?php echo $mark; ?></td>
          <td><?php echo $comment; ?></td>
				</tr>
				<?php
				 $count ++;
				}?>
			</tbody>
		</table>
	</div>
	</center>

    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>