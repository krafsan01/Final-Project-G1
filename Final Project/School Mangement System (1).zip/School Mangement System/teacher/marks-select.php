<?php include('includes/header.php');?>
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>Teacher Home</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="student-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Student</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subject</span>
        </a>
      </li>
      <li class="nav-item active ">
        <a class="nav-link" href="marks-select.php">
          <i class="fas fa-marker"></i>
          <span>Manage Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>

    <!--End of Sidebar-->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>


<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Blank Page</li>
        </ol>

        <!-- Page Content -->
        <h1>Manage Marks</h1>
    <hr>
    <div class="card">
      <div class="card-header">
        Give Marks
      </div>
      <div class="card-body">
        <form action="give-marks.php" method="post">
          <div class="form-row">
            <div class="col-md-3 mb-3">
              <label for="validationCustom01">Exam</label>
              <select class="custom-select" name="marks_exam" required>
                <option selected>Select Exam</option>
                <?php
                $selectExamfordd = "SELECT exam_no, exam_name FROM exams";
                $e_result = mysqli_query($conn, $selectExamfordd);
                while ($row = mysqli_fetch_array($e_result)) {
                echo "<option value='" .$row['exam_no'] . "'>" . $row['exam_name'] . "</option>";
                }?>
              </select>
            </div>
            <div class="col-md-3 mb-3">
              <label for="validationCustom02">Class</label>
              <select class="custom-select" id="classes" name="marks_class" required>
                <option value="0">Select Class</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
                <option value="4">Four</option>
                <option value="5">Five</option>
              </select>
            </div>
            <div class="col-md-4 mb-3">
              <label for="validationCustomUsername">Subject</label>
              <div class="input-group">
                <select class="custom-select" id="subjects" name="marks_subject">
                  <option>Select Subject</option>
                </select>
              </div>
            </div>
            <div class="col-md-2 mb-3" style="margin-top: 30px;">
              <center>
                <button type="submit" class="btn btn-dark">Manage Marks</button>
                </center>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>
<script type="text/javascript">
$(document).ready(function()
{
$("#classes").change(function()
{
var class_no=$(this).val();
var post_no = 'no='+ class_no;
 
$.ajax
({
type: "POST",
url: "/School Mangement System/admin/subject_dependency.php",
data: post_no,
cache: false,
success: function(subjects)
{
$("#subjects").html(subjects);
} 
});
 
});
});
</script>
<?php include('includes/footer.php');?>