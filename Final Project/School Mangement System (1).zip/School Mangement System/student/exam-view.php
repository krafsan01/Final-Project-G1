<?php include('includes/header.php');?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>My Profile</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Teachers</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subjects</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="exam-view.php">
          <i class="fas fa-marker"></i>
          <span>Your Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="login.html">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->

<div id="content-wrapper">

<div class="container-fluid">
  <!-- Breadcrumbs-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">
      <a href="dashboard.php">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Select Exam</li>
  </ol>
  <!-- Page Content -->
  <h1>Manage Marks</h1>
  <hr>
  <div class="card-deck">
    <div class="col-md-4">
    </div>
    <div class="card mb-4">
      <div class="card-body">
        <form action="marks-view.php" method="post">
          <h4 class="card-title">Select Exam</h4>
          <select class="custom-select" name="marks_exam" required>
            <option selected>Select Exam</option>
            <?php
            $selectExamfordd = "SELECT exam_no, exam_name FROM exams";
            $e_result = mysqli_query($conn, $selectExamfordd);
            while ($row = mysqli_fetch_array($e_result)) {
            echo "<option value='" .$row['exam_no'] . "'>" . $row['exam_name'] . "</option>";
            }?>
          </select>
          <button type="submit" class="btn btn-dark">View Marks</button>
        </form>
      </div>
    </div>
    <div class="col-md-4">
    </div>
  </div>
  
  </div>
</div>
<!-- End Page Content -->
</div>
  <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>