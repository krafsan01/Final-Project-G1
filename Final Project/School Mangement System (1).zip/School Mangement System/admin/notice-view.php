<?php include('includes/header.php');?>
<?php
  $pageno = $no_of_records_per_page = $offset = $total_rows =$total_pages=0;

  //pagenation code
  if (isset($_GET['pageno'])) {
    $pageno = (int)$_GET['pageno'];
  } 
  else {
    $pageno = 1;
  }

  $no_of_records_per_page = 2;
  $offset = ($pageno-1) * $no_of_records_per_page;


  $total_pages_sql = "SELECT COUNT(*) FROM notices";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_rows = mysqli_fetch_array($result)[0];
  $total_pages = ceil($total_rows / $no_of_records_per_page);

  //select data
  $sqlNotices = "SELECT notice_id, notice_title,notice, notice_date, notice_show FROM notices WHERE notice_show = 1 LIMIT $offset, $no_of_records_per_page";

  $result = mysqli_query($conn, $sqlNotices);
  $count=1;

?>
<? php echo $notice_id; ?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="student-add.php">Admit Student</a>
      <a class="dropdown-item" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown ">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu " aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item " href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown active show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item active" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->
<!-- Edit Modal-->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Notice</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="notice-edit.php?page=<?php echo $_GET['pageno']?>" method="post">
        
        <div class="modal-body">
          <!-- <input type="hidden" name="update_id" id="update_id">-->
          <div class="form-group row">
           <label for="inputText3" class="col-sm-2 col-form-label">Notice Id</label>
        <div class="col-sm-10">
          <input type="text" class="form-control"  name="notice_id" id="n_id" placeholder="Notice Id" required readonly>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice Title</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="notice_title" id="n_title" placeholder="Notice Title" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="notice" id="notice" placeholder="Notice" required>
        </div>
      </div>
      
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice Date</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" id="n_date" name="notice_date" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Show</label>
        <div class="col-sm-10">
        <select class="custom-select" name="notice_show" id="nshow" required>
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select>
        </div>
      </div>
      </div>

        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-primary" name="updatedata" type="submit" >Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End Edit Modal-->
<!-- Delete Modal-->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Notice</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <form action="notice-delete.php?page=<?php echo $_GET['pageno']?>" method="post">
        
        <div class="modal-body">
          <input type="hidden" name="notice_id" id="ds_id">
          <h4>Do You Want To Delete This Data?</h4>
          
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <button class="btn btn-danger" name="deletedata" type="submit" >Delete</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End Delete Modal-->
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Notice</a>
      </li>
      <li class="breadcrumb-item active">Notice Information</li>
    </ol>
    <!-- Page Content -->
    <div class="form-group row">
      <div class="col-sm-11">
        <h1><i class="fas fa-table"></i> Notice Information</h1>
      </div>
    </div>

    <hr>
    <table class="table table-hover table-bordered">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Notice Id</th>
          <th scope="col">Notice Title</th>
          <th scope="col">Notice</th>
          <th scope="col">Notice Date</th>
          <th scope="col">Show</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td scope="row"><?php echo $count; ?></td>
          <td><?php echo $row['notice_id']; ?></td>
          <td><?php echo $row['notice_title']; ?></td>
          <td><?php echo $row['notice']; ?></td>
          <td><?php echo $row['notice_date']; ?></td>
          <td><?php echo $row['notice_show']; ?></td>
          <td class="sorting_1">&nbsp;&nbsp;
           <button type="button" class="btn btn-success btm-sm editbtn" data-toggle="modal" data-target="#editmodal"
            data-id="<?php echo $row['notice_id']; ?>"
            data-ntitle="<?php echo $row['notice_title']; ?>"
            data-notice="<?php echo $row['notice']; ?>"
            data-ndate="<?php echo $row['notice_date']; ?>"
            data-nshow="<?php echo $row['notice_show']; ?>"
           
            ><i class="fa fa-edit"></i></button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button type="button" class="btn btn-danger btm-sm deletebtn" data-toggle="modal" data-target="#deletemodal" data-id = "<?php echo $row['notice_id']; ?>"><i class="fa fa-trash"></i></button>
          </td>
        </tr>
        <?php $count++; } ?>
      </tbody>
    </table>

    <ul class="pagination justify-content-end">
      

      <li class="paginate_button page-item previous <?php if($pageno <= 1){ echo "disabled"; } ?>"
      id="dataTable_previous"><a href="notice-view.php?pageno=1?pageno=<?php 
      if($pageno <= 1){ echo '#'; } else { echo (strval($pageno - 1)); } ?>" 
      aria-controls="dataTable" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li>
      
      <?php
      for($i=1; $i<=$total_pages; $i++){ ?>
      <li class="paginate_button page-item" id="<?php echo $i; ?>"><a href="notice-view.php?pageno=1?pageno=<?php echo $i; ?>" aria-controls="dataTable" data-dt-idx="1" tabindex="0" class="page-link"><?php echo $i;} ?></a></li>
      

      <li class="paginate_button page-item next <?php if($pageno >= $total_pages){ echo 'disabled'; } ?>" 
      id="dataTable_next"><a href="notice-view.php?pageno=1?pageno=<?php 
      if($pageno >= $total_pages){ echo '#'; } else { echo (strval($pageno + 1)); } ?>" 
      aria-controls="dataTable" data-dt-idx="7" tabindex="0" class="page-link">Next</a></li>



    </ul>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>
  
  <!-- Scripts for Modal And Fetching data from table-->
<script type="text/javascript">
$(document).on( "click", '.editbtn',function(e) {

    //var update_id = $(this).data('no');
    var n_id = $(this).data('id');
    var n_title = $(this).data('ntitle');
    var notice = $(this).data('notice');
    var n_date = $(this).data('ndate');
    var n_show = $(this).data('nshow');
    
    
    

    //$('#update_id').val(update_id);
    $('#n_id').val(n_id);
    $('#n_title').val(n_title);
    $('#notice').val(notice);
    $('#n_date').val(n_date);
    $('#n_show').val(n_show);
    

});
</script>

<script type="text/javascript">
$(document).on( "click", '.deletebtn',function(e) {

    var n_id = $(this).data('id');
    
    
    $('#ds_id').val(n_id);

});

/*$(document).ready( function () {
    $('.table').DataTable();
} );*/

$('<?php echo "#".$pageno; ?>').addClass('active');
</script>

<?php include('includes/footer.php');?>