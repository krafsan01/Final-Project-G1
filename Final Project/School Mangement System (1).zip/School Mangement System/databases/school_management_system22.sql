SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_management_system22`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_no` int(60) NOT NULL,
  `admin_id` varchar(60) NOT NULL,
  `admin_name` varchar(60) NOT NULL,
  `admin_father` varchar(60) NOT NULL,
  `admin_mother` varchar(60) NOT NULL,
  `admin_address` varchar(60) NOT NULL,
  `admin_dob` varchar(60) NOT NULL,
  `admin_email` varchar(60) NOT NULL,
  `admin_phone` varchar(60) NOT NULL,
  `admin_gender` varchar(60) NOT NULL,
  `admin_jd` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_no`, `admin_id`, `admin_name`, `admin_father`, `admin_mother`, `admin_address`, `admin_dob`, `admin_email`, `admin_phone`, `admin_gender`, `admin_jd`) VALUES
(1, '11-0001', 'Peter Scmeil', 'Rob Scmeil', 'Judi Scmeil', 'New York', '2019-12-13', 'asifuli751@gmail.com', '01672662344', 'Male', '2019-12-11'),
(3, '11-0012', 'Rob Scmeil', 'bbb', 'xcvxcvc', 'Australia', '2006-02-14', 'Rob@gmail.com', '36894613451', 'Female', '2016-06-21'),
(4, '11-0003', 'Constanza', 'ertret', 'uuu', 'Australia', '2011-02-03', 'Constanza@gmail.com', '56469789', 'Male', '2019-12-01'),
(5, '11-0004', 'Cristobal', ' Juan', 'Fernanda', 'Australia', '2006-06-13', 'Cristobal@gmail.com', '897638545', 'Male', '2015-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_no` int(60) NOT NULL,
  `book_id` varchar(60) NOT NULL,
  `book_name` varchar(60) NOT NULL,
  `book_author` varchar(60) NOT NULL,
  `book_edition` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_no`, `book_id`, `book_name`, `book_author`, `book_edition`) VALUES
(1, '0001', 'Bangla', 'Asif', '10'),
(2, '0002', 'English', 'aaa', '12'),
(3, '0003', 'GK', 'Jose', '9');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_no` int(20) NOT NULL,
  `class_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_no`, `class_name`) VALUES
(1, 'One'),
(2, 'Two'),
(3, 'Three'),
(4, 'Four'),
(5, 'Five');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_no` int(60) NOT NULL,
  `exam_id` varchar(60) NOT NULL,
  `exam_name` varchar(60) NOT NULL,
  `exam_date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`exam_no`, `exam_id`, `exam_name`, `exam_date`) VALUES
(1, '0001', 'Mid Term', '2020-08-05'),
(2, '0002', 'Test Term', '2020-01-15'),
(3, '0003', 'Final Exam', '2020-11-16'),
(4, '0004', 'Test Exam', '2019-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `mark_no` int(60) NOT NULL,
  `student_no` int(60) NOT NULL,
  `exam_no` int(60) NOT NULL,
  `subject_no` int(60) NOT NULL,
  `mark` int(100) NOT NULL,
  `comment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`mark_no`, `student_no`, `exam_no`, `subject_no`, `mark`, `comment`) VALUES
(1, 1, 1, 1, 92, '\n							Good'),
(2, 1, 1, 2, 75, 'Bad'),
(3, 2, 3, 4, 88, '\n							Good');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `notice_no` int(60) NOT NULL,
  `notice_id` varchar(60) NOT NULL,
  `notice_title` varchar(60) NOT NULL,
  `notice` text NOT NULL,
  `notice_date` varchar(60) NOT NULL,
  `notice_show` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`notice_no`, `notice_id`, `notice_title`, `notice`, `notice_date`, `notice_show`) VALUES
(1, '001', 'Mid Term exam', 'Dear students your mid term exam is near....Best Regards', '2019-12-26', 1),
(2, '002', 'Final Term exam', 'Dear students your mid term exam is near....Best Regards.26 December is your project Submission.So please come to my office at 2 pm', '2019-12-19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_no` int(60) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_father` varchar(100) NOT NULL,
  `student_mother` varchar(100) NOT NULL,
  `student_dob` varchar(100) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `student_address` varchar(100) NOT NULL,
  `student_phone` varchar(100) NOT NULL,
  `student_gender` varchar(100) NOT NULL,
  `student_class` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_no`, `student_id`, `student_name`, `student_father`, `student_mother`, `student_dob`, `student_email`, `student_address`, `student_phone`, `student_gender`, `student_class`) VALUES
(1, '22-0001', 'Jak', 'Jook Mark', 'xyz', '2010-01-05', 'jak@gmail.com', 'NewYork', '++0041564764', 'Male', 1),
(2, '22-0002', 'Ethan', 'abc', 'bbb', '2011-02-09', 'ethan@gmail.com', 'Australia', '+966504499463', 'Male', 2),
(3, '22-0003', 'Lucas', 'Nathan', 'Clara', '2009-02-26', 'lucas@gmail.com', 'Australia', '0041564764', 'Male', 3),
(4, '22-0004', 'Luca', 'Nathan', 'Clara', '2008-10-31', 'luca01@gmail.com', 'Australia', '++0041564764', 'Female', 5);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_no` int(60) NOT NULL,
  `subject_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_no`, `subject_name`) VALUES
(1, 'Bangla'),
(2, 'English'),
(3, 'Math'),
(4, 'ICT'),
(5, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `subjects_teachers`
--

CREATE TABLE `subjects_teachers` (
  `st_no` int(11) NOT NULL,
  `subject_no` int(60) NOT NULL,
  `teacher_no` int(60) NOT NULL,
  `class_no` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects_teachers`
--

INSERT INTO `subjects_teachers` (`st_no`, `subject_no`, `teacher_no`, `class_no`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(3, 3, 2, 1),
(4, 4, 1, 2),
(5, 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_no` int(60) NOT NULL,
  `teacher_id` varchar(60) NOT NULL,
  `teacher_name` varchar(60) NOT NULL,
  `teacher_address` varchar(60) NOT NULL,
  `teacher_merit` varchar(60) NOT NULL,
  `teacher_email` varchar(60) NOT NULL,
  `teacher_phone` varchar(60) NOT NULL,
  `teacher_gender` varchar(60) NOT NULL,
  `teacher_dob` varchar(60) NOT NULL,
  `teacher_jd` varchar(60) NOT NULL,
  `teacher_dept` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_no`, `teacher_id`, `teacher_name`, `teacher_address`, `teacher_merit`, `teacher_email`, `teacher_phone`, `teacher_gender`, `teacher_dob`, `teacher_jd`, `teacher_dept`) VALUES
(1, '33-0001', 'peter', 'Ramna', 'BSC', 'peter@gmail.com', '56458897', 'Male', '2012-02-16', '2019-12-03', '3'),
(2, '33-0002', 'Juker', 'Ramna', 'MSc', 'juker@gmail.com', '56458897', 'Male', '2003-06-26', '2019-12-01', '4'),
(3, '33-0003', 'Manon', 'Ramna', 'BSC', 'manon12@gmail.com', '5647946145', 'Male', '2001-12-26', '2018-06-13', '1'),
(4, '33-0004', 'Marie', 'Australia', 'BSc ,MSc', 'marie@gmail.com', '899999456', 'Female', '2004-02-10', '2016-10-25', '3');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `no` int(60) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`no`, `user_name`, `password`) VALUES
(1, '11-0001', '$2y$10$m/Soq7/T/ZlOEf4.9XK2SuDZIxPzKmOFtwr.CpLz55UMhYuWbkUNG'),
(21, '22-0001', '$2y$10$UJ6zwykDwdxQ8YrvWU/EseUTg3.vlbXvSNVR5KjBato/4WfOAl20q'),
(22, '22-0002', '$2y$10$AEUFSLARnn3mAZES36xHTerknw1gFiU/4d7dmB73eYbmQBVHKTGwO'),
(23, '22-0003', '$2y$10$Y9bNhk5MW5T1ixj1VRgetuhZw/RB/6VmVHJAzvyk5qymBs7zJxq2W'),
(24, '33-0001', '$2y$10$9F8dvfcbE2cQ7QfUIyUlZO0OWyOb5wh.M44audLwTxm4yR3CM9g.O'),
(25, '33-0002', '$2y$10$.cMKvRxMmmZD3eXKX/vEGue4ms08mn2L/WXxKFGNSkwdS3KhgL4u.'),
(26, '33-0003', '$2y$10$jN/a4JXnAsaPagKMFgKQQO4ktoAF9bqoY8gEgNe.f6fyC6lVErJai'),
(27, '33-0004', '$2y$10$o.mEt5s4WKZeGqpAJ9FNfOM/Ta/3BwTqWHKeOUPFK0GwyJhwpeYVa'),
(28, '22-0004', '$2y$10$L6VIBk1XvIR5MEJ19AyMDuhrqM17XkXlzSct4vkie36CdsN94wElG'),
(29, '11-0012', '$2y$10$ffxRuQqHgjcXCSTHGJm3zeGU5C57IaDwjyoBq3dS6ZXLrZJW6FC6q'),
(30, '11-0003', '$2y$10$ML8BtyczF/VNJ4NiWZgt9.l3B7MvSZybtsYm0Js2rSi8zqdy/j2bS'),
(31, '11-0004', '$2y$10$ESbvpebniBYtLxt5dugu0OAcd4kJ7pdWUgzuGjDdkx8.FRCfsroXK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_no`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_no`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_no`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_no`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`mark_no`),
  ADD KEY `student_no` (`student_no`),
  ADD KEY `exam_no` (`exam_no`),
  ADD KEY `subject_no` (`subject_no`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`notice_no`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_no`),
  ADD KEY `student_class` (`student_class`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_no`);

--
-- Indexes for table `subjects_teachers`
--
ALTER TABLE `subjects_teachers`
  ADD PRIMARY KEY (`st_no`),
  ADD KEY `subject_no` (`subject_no`),
  ADD KEY `teacher_no` (`teacher_no`),
  ADD KEY `class_no` (`class_no`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `mark_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `notice_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjects_teachers`
--
ALTER TABLE `subjects_teachers`
  MODIFY `st_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `no` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`student_no`) REFERENCES `students` (`student_no`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`exam_no`) REFERENCES `exams` (`exam_no`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`subject_no`) REFERENCES `subjects` (`subject_no`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`student_class`) REFERENCES `classes` (`class_no`) ON DELETE CASCADE;

--
-- Constraints for table `subjects_teachers`
--
ALTER TABLE `subjects_teachers`
  ADD CONSTRAINT `subjects_teachers_ibfk_1` FOREIGN KEY (`subject_no`) REFERENCES `subjects` (`subject_no`) ON DELETE CASCADE,
  ADD CONSTRAINT `subjects_teachers_ibfk_2` FOREIGN KEY (`teacher_no`) REFERENCES `teachers` (`teacher_no`) ON DELETE CASCADE,
  ADD CONSTRAINT `subjects_teachers_ibfk_3` FOREIGN KEY (`class_no`) REFERENCES `classes` (`class_no`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
