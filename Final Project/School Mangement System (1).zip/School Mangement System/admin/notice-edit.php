<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

$notice_id=$notice_title=$notice=$notice_date=$notice_show="";

  if(isset($_POST['updatedata'])){
    
    $notice_id = mysqli_real_escape_string($conn, $_POST['notice_id']);
    $notice_title = mysqli_real_escape_string($conn, $_POST['notice_title']);
    $notice = mysqli_real_escape_string($conn, $_POST['notice']);
    $notice_date = mysqli_real_escape_string($conn, $_POST['notice_date']);
    $notice_show = mysqli_real_escape_string($conn, $_POST['notice_show']);
    

    $sql_notice = "UPDATE notices SET notice_title ='$notice_title', notice ='$notice',notice_date ='$notice_date',notice_show ='$notice_show' WHERE notice_id = '$notice_id';";
    $query_run = mysqli_query($conn, $sql_notice);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:notice-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>