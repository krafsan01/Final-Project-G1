<?php include('includes/header.php');?>
<?php

include "../includes/db_connect.inc.php";

$teacher_id=$teacher_name=$teacher_address=$teacher_merit=$teacher_email=$teacher_phone=$teacher_gender=$teacher_dob=$teacher_jd=$teacher_dept="";

$result=$messege=$success_messege=$sql_teacher=$sql_login=$password=$passwordHash="";
$teacher_idInDB=$teacher_id_err="";

if($_SERVER['REQUEST_METHOD'] == "POST"){
  
    if((!empty($_POST['teacher_id']))&&(!empty($_POST['teacher_name']))&& (!empty($_POST['teacher_address']))&& (!empty($_POST['teacher_merit'])) && (!empty($_POST['teacher_email'])) && (!empty($_POST['teacher_phone'])) && (!empty($_POST['teacher_gender']) )&& (!empty($_POST['teacher_dob'])) && (!empty($_POST['teacher_jd'])) && (!empty($_POST['teacher_dept'])))
    {
      $teacher_id = mysqli_real_escape_string($conn, $_POST['teacher_id']);
      $teacher_name = mysqli_real_escape_string($conn, $_POST['teacher_name']);
      $teacher_address = mysqli_real_escape_string($conn, $_POST['teacher_address']);
      $teacher_dob = mysqli_real_escape_string($conn, $_POST['teacher_dob']);
      $teacher_email = mysqli_real_escape_string($conn, $_POST['teacher_email']);
      $teacher_phone = mysqli_real_escape_string($conn, $_POST['teacher_phone']);
      $teacher_gender = mysqli_real_escape_string($conn, $_POST['teacher_gender']);
      $teacher_dept = mysqli_real_escape_string($conn, $_POST['teacher_dept']);
      $teacher_merit = mysqli_real_escape_string($conn, $_POST['teacher_merit']);
      $teacher_jd = mysqli_real_escape_string($conn, $_POST['teacher_jd']);
    }
  


    $sqlUserCheck = "SELECT teacher_id FROM teachers WHERE teacher_id = '$teacher_id'";
    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $teacher_idInDB = $row['teacher_id'];
    }
    $check=(bool)$teacher_idInDB == $teacher_id;
    if($teacher_idInDB == $teacher_id){
      $teacher_id_err = "Same teacher_id already exists!";
    }
    else
    {
      $sql_teacher = "INSERT INTO teachers (teacher_id,teacher_name, teacher_address,teacher_merit, teacher_email, teacher_phone,teacher_gender,teacher_dob,teacher_jd,teacher_dept) VALUES ('$teacher_id', '$teacher_name','$teacher_address','$teacher_merit','$teacher_email' , '$teacher_phone','$teacher_gender', '$teacher_dob','$teacher_jd','$teacher_dept');";
      mysqli_query($conn, $sql_teacher);
      
      $password = rand(1000,9999);
      $password_hash = password_hash($password, PASSWORD_DEFAULT);
      $sql_login = "INSERT INTO users (user_name, password) VALUES ('$teacher_id','$password_hash');";
      mysqli_query($conn, $sql_login);
      $success_messege = "Data Inserted!, password is: ".$password ;
    }

}



?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="student-add.php">Admit Student</a>
      <a class="dropdown-item" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown active show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item active" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item" href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Teacher</a>
      </li>
      <li class="breadcrumb-item active">Admit Teacher</li>
    </ol>
    <!-- Page Content -->
    <h1>Admit Teacher</h1>
    <hr>
    <form role="form" method="post">
      <input type="hidden" name="new" value="1" />
      <div class="form-group row">
        <label for="inputText3" class="col-sm-2 col-form-label">Teacher Id</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputText3" name="teacher_id" placeholder="Teacher Id" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Teacher Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="teacher_name" placeholder="Teacher Name" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Teacher Address</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="teacher_address" placeholder="Teacher Address" required>
        </div>
      </div>
      
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Date of Birth</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" name="teacher_dob" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name="teacher_email" placeholder="@Email" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Phone</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="teacher_phone" placeholder="Phone" required>
        </div>
      </div>
      <fieldset class="form-group">
        <div class="row">
          <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
          <div class="col-sm-10">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="teacher_gender" value="Male" checked>
              <label class="form-check-label">
                Male
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="teacher_gender" value="Female">
              <label class="form-check-label">
                Female
              </label>
            </div>
          </div>
        </div>
      </fieldset>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Department</label>
        <div class="col-sm-10">
          <select class="custom-select" name="teacher_dept" required>
            <option selected>Select Department</option>
            <option value="1">Math</option>
            <option value="2">Bangla</option>
            <option value="3">English</option>
            <option value="4">ICT</option>
            <option value="5">Religious</option>
          </select>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Merit</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="teacher_merit" placeholder="Teacher Merit" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Join Date</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" name="teacher_jd" required>
        </div>
      </div>
      
      <div class="form-group row">
        <div class="col-sm-12">
          <button type="submit" class="btn btn-primary">Save</button>
          <span class="text-success"><?php echo $success_messege?></span>
          <span class="text-danger"><?php echo $teacher_id_err ?></span>
        </div>
      </div>
    </form>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>
 <!-- <script>
$( "form" ).submit(function( event ) {
  var id = "<?php //echo $student_id?>";
  var idInDB = "<?php //echo $student_idInDB?>";

  if ( <?php //echo $check ?> ) {
    $( ".text-success" ).text( "<?php //echo $success_messege?>" ).show();
    return;
  }

  $("#inputText3").val("");
  $( ".text-danger" ).text("Same student_id already exists!").show().fadeOut( 3000 );
  event.preventDefault();
});
</script>-->
  <?php include('includes/footer.php');?>