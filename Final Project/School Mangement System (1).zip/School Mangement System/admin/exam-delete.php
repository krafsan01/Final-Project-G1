<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

  if(isset($_POST['deletedata'])){
    $id = $_REQUEST['exam_id'];
    $query = "DELETE FROM exams WHERE exam_id='$id'"; 
    $query_run = mysqli_query($conn,$query);
  }
  header("Location: exam-view.php?pageno=1");
  if($query_run)
    {
      echo '<script> alert("Data Deleted"); </script>';
      header("location:exam-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did not Deleted"); </script>';
    }
?>