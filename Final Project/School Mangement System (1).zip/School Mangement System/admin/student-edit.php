<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

$student_id=$student_name=$student_father=$student_mother=$student_dob=$student_email=$student_address=$student_phone=$student_gender=$student_class="";

  if(isset($_POST['updatedata'])){
    
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $student_father = mysqli_real_escape_string($conn, $_POST['student_father']);
    $student_mother = mysqli_real_escape_string($conn, $_POST['student_mother']);
    $student_dob = mysqli_real_escape_string($conn, $_POST['student_dob']);
    $student_email = mysqli_real_escape_string($conn, $_POST['student_email']);
    $student_address = mysqli_real_escape_string($conn, $_POST['student_address']);
    $student_phone = mysqli_real_escape_string($conn, $_POST['student_phone']);
    $student_gender = mysqli_real_escape_string($conn, $_POST['student_gender']);
    $student_class = mysqli_real_escape_string($conn, ((int)$_POST['student_class']));
    

    $sql_student = "UPDATE students SET student_name ='$student_name', student_father ='$student_father', student_mother ='$student_mother',student_dob='$student_dob', student_email ='$student_email', student_address ='$student_address',student_phone='$student_phone',student_gender='$student_gender',student_class='$student_class' WHERE student_id = '$student_id';";
    $query_run = mysqli_query($conn, $sql_student);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:student-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>